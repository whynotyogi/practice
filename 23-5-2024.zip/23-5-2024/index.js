
// class person{
//     constructor(name,id,age){
//         this.name=name;
//         this.id=id;
//         this.age=age;
//     }
// }
// let person1=new person("virat kohli",18,35);
// document.write(person1.name+"<br>");
// document.write(person1.id+"<br>")
// document.write(person1.age+"<br>")



// class x{
//     constructor(a,b,c){
//         this.g=a;
//         this.e=b;
//         this.f=c;
//     }
//     print(){
//         document.write(this.g+" "+this.e+" "+this.f+"<br>");
//     }
// }
// let y=new x("java","script","programming");
// y.print();


// class men{
//     constructor(name,id){
//         this.name=name;
//         this.id=id;
//     }
//     add_Address(add){
//         this.add=add;
//     }
//     getDetails(){
//         document.write(`${this.name} ${this.id} ${this.add}`+"<br>");
//     }
// }
// let men1= new men("virat",18);
// men1.add_Address("Delhi");
// men1.getDetails();


// function rr(fname,lname){
//     let firstname=fname;
//     let lastname=lname;
//     let getDetails_noaccess=function(){
//         return(`${firstname},${lastname}`)
//     }
//     this.getDetails_access=function(){
//         return(`${firstname},${lastname}`);
//     }
// }
// let rr1=new rr("virat","kohli");
// document.write(rr1.firstname+"<br>");
// document.write(rr1.getDetails_noaccess+"<br>");
// document.write(rr1.getDetails_access+"<br>");

// class men{
//     constructor(name){
//         this.name=name;
//     }
//     toString(){
//         return(`${this.name}`);
//     }
// }
// class student extends men{
//     constructor(name,id){
//         super(name);
//         this.id=id;
//     }
//     toString(){
//         return(`${super.toString()} ${this.id}`)
        
//     }
// }
// let student1=new student("virat",18);
// document.write(student1.toString());


// let age=prompt("HELLO WORLD");
// console.log(age);


function insertElements(arr,n,x,pos){
    for(var i=n-1;i>=pos;i++){
        arr[i+1]=arr[i];
    }
    arr[pos]=x;
}
var arr=Array(15).fill(0);
arr[0]=2;
arr[1]=4;
arr[2]=1;
arr[3]=8;
arr[4]=5;
var n=5;
var x=10;
var pos=2;
console.log("before insertion");
for(var i=0;i<n;i++){
    console.log(arr[i]);
}
insertElements(arr,n,x,pos);
n+=1;
console.log("\n after insertion");
for(var i=0;i<n;i++){
    console.log(arr[i]);
}